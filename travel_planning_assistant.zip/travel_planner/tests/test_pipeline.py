"""Smoke tests on the SYNTHETIC mock data (no Kaggle download needed).

Run from the project root:
    python tests/make_mock_data.py
    python tests/test_pipeline.py
Trained model/reports go to a temporary folder, so the real models/ is untouched.
"""
import os
import sys
import tempfile
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["DATA_DIR"] = str(ROOT / "tests" / "mock_data")
os.environ["MAAS_BASE_URL"] = ""  # force offline mode

from src import config  # noqa: E402

tmp = Path(tempfile.mkdtemp())
config.MODEL_DIR, config.REPORT_DIR = tmp, tmp
config.MODEL_PATH, config.MODEL_META_PATH = tmp / "m.joblib", tmp / "m.json"

from src.agents import TravelOrchestrator  # noqa: E402
from src.preference_model import PreferenceModel  # noqa: E402
from src.rag import RAG  # noqa: E402
from src.train_models import main as train  # noqa: E402

PROFILE = dict(Age=35, CityTier=1, NumberOfPersonVisiting=2, PreferredPropertyStar=4, NumberOfTrips=3,
               Passport=1, OwnCar=1, NumberOfChildrenVisiting=0, MonthlyIncome=28000,
               Occupation="Salaried", Gender="Male", MaritalStatus="Married")


def test_all():
    results = train()
    assert len(results) >= 3, "need at least three models"

    orch = TravelOrchestrator(PreferenceModel())
    start = date.today() + timedelta(days=20)

    r = orch.plan_trip(PROFILE, "Delhi", "Mumbai", start, start + timedelta(days=3), 80000, ["Historical"])
    assert r["tier"] in config.TIER_ORDER
    assert r["transport"]["mode"] == "Flight"
    assert len(r["itinerary"]) == 4
    for d in r["itinerary"]:
        assert d["hours"] <= config.DAILY_HOURS
        day = d["date"].split()[0]
        for s in d["stops"]:
            off = r["attractions"].set_index("name").loc[s["name"], "weekly_off"]
            assert day.lower()[:3] not in str(off).lower(), "scheduled on weekly off day"

    r2 = orch.plan_trip(PROFILE, "Delhi", "Jaipur", start, start + timedelta(days=2), 15000, [])
    assert "estimate" in r2["transport"]["mode"].lower()
    assert r2["budget"]["adjustments"], "budget agent should adjust a low budget"

    rag = RAG()
    _, hits = rag.answer("What is the hotel cancellation policy?")
    assert any("Cancellation" in h["title"] for h in hits)
    _, hits = rag.answer("Is it safe to swim in Goa during the monsoon?")
    assert any("Goa" in h["title"] for h in hits)
    print("ALL TESTS PASSED")


if __name__ == "__main__":
    test_all()
