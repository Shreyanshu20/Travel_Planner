# Final Presentation Outline (covers every item in the brief)

1. **Problem statement & business relevance.** Planning a trip means comparing flights, hotels and sights against a budget. The assistant personalises the plan using ML, agents and RAG.
2. **Dataset sources & justification.** The 4 Kaggle datasets, what each one feeds, and their limitations (from `docs/dataset_sources.md`).
3. **EDA highlights.** Tier distribution, income vs tier, the Designation leakage finding, flight price vs days-left, attraction coverage.
4. **Sprint-wise work completed.** Table from `docs/sprint_log.md`.
5. **Solution architecture.** Diagram from `docs/architecture.md`: the agent flow, the RAG flow and the optimizer.
6. **ML models.** Table and chart from `reports/model_comparison.csv/png`, the confusion matrix, feature importance, and why the best model was chosen.
7. **Agents.** One slide each: Transport, Hotel, Attraction, Budget. Show input → logic → output.
8. **RAG.** Document sources, TF-IDF retrieval and MAAS generation with citations, plus 2 example Q&As.
9. **Bonus: optimized itinerary.** Greedy algorithm, constraints, and a sample output.
10. **Live demo.** Script: (a) Delhi → Mumbai, 4 days, ₹80k; (b) Delhi → Jaipur, low budget, to show the budget agent adjusting; (c) the Ask tab: "cancellation policy?" and "Goa in monsoon?"; (d) the Model report tab.
11. **Key findings & outcomes.**
12. **Challenges & lessons learned.** Missing hotel prices, limited flight coverage, no Kaggle advisory text, leakage, the 6-hour lab sessions.
13. **Team member contributions.** From `docs/team_contributions.md`.
14. **Future work.** Real-time APIs, embeddings with FAISS, multi-city trips, user feedback loop.
