# Team Contributions

The brief requires equal work allocation and clear documentation of each member's contribution.
Fill in this table; every member should be able to explain their part and the overall flow.

| Member | Sprint activities | Files / modules owned | Notes |
|--------|-------------------|-----------------------|-------|
| | | | |
| | | | |
| | | | |
| | | | |
