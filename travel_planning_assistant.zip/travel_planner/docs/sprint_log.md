# Sprint-wise Progress Log

Fill in the dates, observations and outcomes as you run each sprint on the real data.
If your programme defines its own sprint names, map these sprints onto them.

| Sprint | Goal | Deliverables (in repo) | Status | Observations / outcomes |
|--------|------|------------------------|--------|--------------------------|
| 1. Problem & data | Understand requirements; source, validate and document datasets; EDA | `docs/dataset_sources.md`, `notebooks/01_EDA.ipynb`, `src/data_loader.py` | ☐ | e.g. class balance, missing Age/MonthlyIncome, "Fe Male" typo fixed, Designation leakage found |
| 2. ML models | Preprocessing; train and compare ≥3 models; save best | `notebooks/02_Model_Training.ipynb`, `src/train_models.py`, `reports/model_comparison.csv`, `models/` | ☐ | best model + macro-F1; most important features |
| 3. Agents & RAG | Transport, Hotel, Attraction, Budget agents; RAG index + MAAS answers | `src/agents.py`, `src/rag.py`, `src/llm.py`, `data/knowledge_base/` | ☐ | sample RAG questions and answers; agent outputs for 2–3 test trips |
| 4. Optimizer & UI | Itinerary optimizer (bonus); Streamlit integration | `src/optimizer.py`, `app.py` | ☐ | constraints respected (hours, fees, weekly off) |
| 5. Test & present | End-to-end tests; documentation; presentation; demo rehearsal | `tests/`, `README.md`, `docs/presentation_outline.md` | ☐ | test results; demo script |

## Test cases to record (Sprint 5)

| # | Input | Expected | Actual |
|---|-------|----------|--------|
| 1 | Delhi → Mumbai, 4 days, 2 adults, ₹80,000 | Flights found, plan within budget | |
| 2 | Delhi → Jaipur (no flights in data) | Road/rail estimate used, note shown | |
| 3 | Very low budget (₹15,000) | Budget agent downgrades and warns if still over | |
| 4 | Attraction with weekly off | Never scheduled on its closing day | |
| 5 | RAG: "cancellation policy" | Hotel policy chunk retrieved and cited | |
| 6 | RAG: "Goa in monsoon" | Advisory chunk retrieved and cited | |
| 7 | MAAS not configured | App still works (offline answers) | |
