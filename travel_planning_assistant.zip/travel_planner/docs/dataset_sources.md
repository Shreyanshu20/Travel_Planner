# Dataset Sources

All datasets are public Kaggle datasets. Download each one, unzip it and put the
CSV file listed below into `data/raw/` with the file name shown. The loaders in
`src/data_loader.py` match column names flexibly, so small header differences
between dataset versions are handled.

| # | Used for | Kaggle dataset | Search on Kaggle | File to put in `data/raw/` |
|---|----------|----------------|------------------|----------------------------|
| 1 | **ML** – predict customer preference (package tier) | *Holiday Package Purchase Prediction* (Travel / Tour package customers) | `holiday package purchase prediction` (e.g. kaggle.com/datasets/susant4learning/holiday-package-purchase-prediction) | `Travel.csv` |
| 2 | **Transport Agent** – flights between Indian metros | *Flight Price Prediction* (Ease My Trip data, ~300k flights) | `flight price prediction shubhambathwal` (kaggle.com/datasets/shubhambathwal/flight-price-prediction) | `Clean_Dataset.csv` |
| 3 | **Attraction Agent** + RAG tourism guides | *Travel Dataset: Guide to India's Must-See Places* | `top indian places to visit` (kaggle.com/datasets/saketk511/travel-dataset-guide-to-indias-must-see-places) | `Top Indian Places to Visit.csv` |
| 4 | **Hotel Agent** + RAG hotel info | *Hotels on Goibibo* (PromptCloud) | `hotels on goibibo` (kaggle.com/datasets/PromptCloudHQ/hotels-on-goibibo) | `goibibo_com-travel_sample.csv` |

> Verify the dataset URLs when downloading. If a dataset's file has a different
> name, either rename it or change the file name in `src/config.py`.

## Why these datasets

1. **Holiday Package (Travel.csv)**: about 4,900 customers with age, income, occupation, family size, preferred hotel star and the package pitched (Basic, Standard, Deluxe, Super Deluxe, King). The package tier is a direct label for *customer travel preference*, which is the ML task in the case study.
2. **Flight Price Prediction**: real fares, airlines, stops, duration and days before departure for 6 Indian metros (Delhi, Mumbai, Bangalore, Kolkata, Hyderabad, Chennai). It lets the Transport Agent quote realistic fares that change with booking lead time.
3. **India's Must-See Places**: about 325 attractions with city, type, Google rating, entrance fee, time needed, weekly off day and best time of day. These are exactly the fields the itinerary optimizer needs (time, cost, closing days).
4. **Hotels on Goibibo**: about 4,000 Indian hotels with city, star rating, guest rating, facilities and description. They are used for hotel shortlisting and as RAG text.

## Known limitations (state these in the presentation)

- **Hotel prices.** The Goibibo dataset has no tariff column, so the nightly price is estimated from the star rating (`EST_PRICE_BY_STAR` in `src/config.py`) and marked "estimated" in the app. If you switch to a hotel dataset with a price column, it is used automatically.
- **Flight coverage.** Only 6 metro cities have flights. For other destinations (e.g. Jaipur, Goa) the Transport Agent uses a stated road/rail estimate.
- **Hotel policies and travel advisories.** Kaggle has no suitable text dataset for these, so `data/knowledge_base/` contains short team-written reference documents (general Indian hotel policies and seasonal advisories) for the RAG module. **Confirm with your mentor that this is acceptable**, or replace them with an approved source.
- **Designation column.** `Designation` in Travel.csv maps almost one-to-one to the package tier, so it is excluded from the features to avoid target leakage.

## Data compliance

- Datasets are public and open-source. Keep them only in the AI Lab repository, not on other online platforms (instruction 2).
- Only trip details and public dataset text are sent to the MAAS LLM. No personal or confidential data is sent.
