"""Travel Planning Assistant – Streamlit front end.

Run:  streamlit run app.py
"""
from datetime import date, timedelta

import pandas as pd
import streamlit as st

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from src import config, llm
from src.agents import TravelOrchestrator, flights_to_df
from src.data_loader import load_attractions, load_flights
from src.preference_model import PreferenceModel
from src.rag import RAG

st.set_page_config(page_title="Travel Planning Assistant", page_icon="🧳", layout="wide")


# ------------------------------------------------------------------ cached setup
@st.cache_resource(show_spinner="Loading model and datasets…")
def get_orchestrator():
    return TravelOrchestrator(PreferenceModel())


@st.cache_resource(show_spinner="Building the RAG index…")
def get_rag():
    return RAG()


try:
    orch = get_orchestrator()
    rag = get_rag()
except FileNotFoundError as e:
    st.error(f"Setup incomplete: {e}")
    st.info("1. Download the 4 Kaggle CSVs into `data/raw/` (see docs/dataset_sources.md)\n"
            "2. Train the models: `python -m src.train_models`\n3. Restart the app.")
    st.stop()

meta = orch.model.meta
flight_cities = sorted(set(load_flights()["source_city"]))
dest_cities = sorted(set(load_attractions()["city"]))
interest_options = sorted(set(load_attractions()["significance"]))

# ---------------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("🧳 Plan a trip")
    with st.form("trip"):
        st.subheader("Trip")
        source = st.selectbox("From", flight_cities, index=flight_cities.index("Delhi") if "Delhi" in flight_cities else 0)
        default_dest = "Jaipur" if "Jaipur" in dest_cities else dest_cities[0]
        destination = st.selectbox("To", dest_cities, index=dest_cities.index(default_dest))
        start = st.date_input("Start date", date.today() + timedelta(days=21))
        end = st.date_input("End date", date.today() + timedelta(days=24))
        budget = st.number_input("Total budget (₹)", 5000, 2_000_000, 60000, step=5000)
        interests = st.multiselect("Interests", interest_options, default=interest_options[:2])

        st.subheader("About you (for preference prediction)")
        age = st.number_input("Age", 18, 80, 32)
        income = st.number_input("Monthly income (₹)", 5000, 500000, 25000, step=1000)
        c1, c2 = st.columns(2)
        adults = c1.number_input("Adults", 1, 6, 2)
        kids = c2.number_input("Children", 0, 4, 0)
        occupation = st.selectbox("Occupation", meta["categories"]["Occupation"])
        gender = st.selectbox("Gender", meta["categories"]["Gender"])
        marital = st.selectbox("Marital status", meta["categories"]["MaritalStatus"])
        c1, c2 = st.columns(2)
        city_tier = c1.selectbox("Home city tier", [1, 2, 3])
        star = c2.selectbox("Pref. hotel ★", [3, 4, 5])
        trips = st.number_input("Trips per year", 0, 20, 2)
        passport = st.checkbox("Has passport", True)
        own_car = st.checkbox("Owns a car", False)
        override = st.selectbox("Package tier", ["Use ML prediction"] + config.TIER_ORDER)
        submitted = st.form_submit_button("✨ Generate plan")
    st.caption("LLM (MAAS): " + ("connected ✅" if llm.is_configured() else "not configured – offline mode"))

if submitted:
    if end < start:
        st.sidebar.error("End date must be after the start date.")
    else:
        profile = {"Age": age, "CityTier": city_tier, "NumberOfPersonVisiting": adults,
                   "PreferredPropertyStar": star, "NumberOfTrips": trips, "Passport": int(passport),
                   "OwnCar": int(own_car), "NumberOfChildrenVisiting": kids, "MonthlyIncome": income,
                   "Occupation": occupation, "Gender": gender, "MaritalStatus": marital}
        with st.spinner("Agents are planning your trip…"):
            st.session_state.plan = orch.plan_trip(
                profile, source, destination, start, end, budget, interests,
                tier_override=None if override == "Use ML prediction" else override)

# ------------------------------------------------------------------------- tabs
st.title("Travel Planning Assistant")
st.caption("ML preference prediction · Transport, Hotel, Attraction & Budget agents · RAG Q&A · Optimized itineraries")
tab_plan, tab_itin, tab_ask, tab_model = st.tabs(["📋 Plan", "🗓️ Itinerary", "💬 Ask", "📊 Model report"])

plan = st.session_state.get("plan")

with tab_plan:
    if not plan:
        st.info("Fill in the form on the left and click **Generate plan**.")
    else:
        b = plan["budget"]
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Predicted package tier", plan["tier"])
        m2.metric("Trip length", f"{plan['days']} days · {plan['travelers']} pax")
        m3.metric("Estimated total", f"₹{b['total']:,}")
        m4.metric("Remaining budget", f"₹{b['remaining']:,}", delta_color="normal" if b["within_budget"] else "inverse",
                  delta="within budget" if b["within_budget"] else "over budget")

        with st.expander("🤖 Preference model probabilities"):
            probs = pd.Series(plan["probs"]).reindex(config.TIER_ORDER).dropna()
            st.bar_chart(probs)

        st.subheader("✈️ Transport Agent")
        t = plan["transport"]
        st.caption(t["note"])
        if t["mode"] == "Flight":
            c1, c2 = st.columns(2)
            c1.markdown(f"**Outbound {plan['source']} → {plan['destination']}**")
            c1.dataframe(flights_to_df(t["outbound"]), hide_index=True)
            c2.markdown(f"**Return {plan['destination']} → {plan['source']}**")
            c2.dataframe(flights_to_df(t["return"]), hide_index=True)
        else:
            st.write(f"Mode: **{t['mode']}** · total ₹{t['total']:,}")

        st.subheader("🏨 Hotel Agent")
        h = plan["hotel"]
        st.caption(h["note"] + f" {h['rooms']} room(s) × {h['nights']} night(s).")
        hdf = pd.DataFrame(h["options"])
        cols = [c for c in ["name", "locality", "stars", "rating", "price", "cost"] if c in hdf]
        st.dataframe(hdf[cols].rename(columns={"price": "₹/night", "cost": "stay total ₹"}),
                     hide_index=True)
        st.success(f"Selected: **{plan['hotel_choice']['name']}** – ₹{int(plan['hotel_choice']['cost']):,} for the stay")

        st.subheader("📍 Attraction Agent")
        a = plan["attractions"]
        if a.empty:
            st.warning("No attractions found for this city in the dataset.")
        else:
            st.dataframe(a[["name", "type", "significance", "rating", "fee", "hours", "best_time", "weekly_off",
                            "interest_match"]].head(15), hide_index=True)

        st.subheader("💰 Budget Planner Agent")
        c1, c2 = st.columns([2, 1])
        c1.bar_chart(pd.Series(b["breakdown"], name="₹"))
        c2.dataframe(pd.DataFrame({"₹": b["breakdown"]}))
        for adj in b["adjustments"]:
            c2.info(adj)
        if not b["within_budget"]:
            st.error(f"Even after adjustments the trip costs ₹{-b['remaining']:,} more than the budget. "
                     "Try fewer days, a nearer destination or a higher budget.")

with tab_itin:
    if not plan:
        st.info("Generate a plan first.")
    else:
        st.markdown(plan["narrative"])
        s = plan["stats"]
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Attractions", s["attractions"]); c2.metric("Sightseeing hours", s["sightseeing_hours"])
        c3.metric("Fees / person", f"₹{s['fees_per_person']:,}"); c4.metric("Avg rating", s["avg_rating"])
        for d in plan["itinerary"]:
            with st.expander(f"Day {d['day']} · {d['date']} · {d['label']} · {d['hours']} h", expanded=True):
                if d["stops"]:
                    st.dataframe(pd.DataFrame(d["stops"])[["time", "end", "name", "type", "hours", "fee", "rating"]],
                                 hide_index=True)
                else:
                    st.write("Free time / rest / travel.")
        rows = [dict(day=d["day"], date=d["date"], **s) for d in plan["itinerary"] for s in d["stops"]]
        if rows:
            st.download_button("⬇️ Download itinerary (CSV)", pd.DataFrame(rows).to_csv(index=False),
                               file_name="itinerary.csv", mime="text/csv")

with tab_ask:
    st.write("Ask about **attractions, hotels, hotel policies or travel advisories**. "
             "Answers are retrieved from the knowledge base (RAG).")
    st.caption("Try: *What is the cancellation policy?* · *Is it safe to visit Goa in monsoon?* · "
               "*Which forts are in Jaipur?* · *What ID do I need at check-in?*")
    if "chat" not in st.session_state:
        st.session_state.chat = []
    for role, msg in st.session_state.chat:
        st.chat_message(role).markdown(msg)
    q = st.chat_input("Your question")
    if q:
        st.chat_message("user").markdown(q)
        ans, hits = rag.answer(q)
        with st.chat_message("assistant"):
            st.markdown(ans)
            if hits:
                with st.expander("Sources"):
                    for i, h in enumerate(hits, 1):
                        st.write(f"[{i}] {h['source']} – {h['title']} (score {h['score']})")
        st.session_state.chat += [("user", q), ("assistant", ans)]

with tab_model:
    st.write(f"Target: **{config.TARGET}** (customer's preferred package tier) · best model: "
             f"**{meta['best_model']}** · trained on {meta['train_rows']:,} customers.")
    comp = config.REPORT_DIR / "model_comparison.csv"
    if comp.exists():
        st.dataframe(pd.read_csv(comp), hide_index=True)
    c1, c2 = st.columns(2)
    for col, img, cap in [(c1, "model_comparison.png", "Model comparison"),
                          (c2, "confusion_matrix.png", "Confusion matrix (best model)"),
                          (c1, "feature_importance.png", "Feature importance")]:
        p = config.REPORT_DIR / img
        if p.exists():
            col.image(str(p), caption=cap)
