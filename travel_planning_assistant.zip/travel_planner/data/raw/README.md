Put the 4 Kaggle CSV files here (see ../../docs/dataset_sources.md):

- Travel.csv
- Clean_Dataset.csv
- Top Indian Places to Visit.csv
- goibibo_com-travel_sample.csv
