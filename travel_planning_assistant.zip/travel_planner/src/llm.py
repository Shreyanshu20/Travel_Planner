"""Thin LLM client for the MAAS endpoint (OpenAI-compatible chat API).

Set MAAS_BASE_URL, MAAS_API_KEY and MAAS_MODEL in .env as given in the MAAS
folder of the AI Lab VM. If they are not set, or the call fails, every caller
falls back to a deterministic template, so the app always works offline.
Follow the MAAS guidelines: send only the trip request and retrieved public
dataset text, never personal or confidential data.
"""
from src import config


def is_configured() -> bool:
    return bool(config.MAAS_BASE_URL and config.MAAS_API_KEY and config.MAAS_MODEL)


def chat(system: str, user: str, temperature: float = 0.3, max_tokens: int = 800):
    """Return the model's reply, or None if MAAS is not configured / fails."""
    if not is_configured():
        return None
    try:
        from openai import OpenAI
        client = OpenAI(base_url=config.MAAS_BASE_URL, api_key=config.MAAS_API_KEY)
        resp = client.chat.completions.create(
            model=config.MAAS_MODEL,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
            temperature=temperature, max_tokens=max_tokens,
        )
        return resp.choices[0].message.content
    except Exception as e:  # network / auth / quota problems -> offline fallback
        print(f"[llm] MAAS call failed, using fallback: {e}")
        return None
