"""The four planning agents and the orchestrator that runs them in order.

Each agent is a small class with a single run() method working on a Kaggle
dataset. The orchestrator passes results from one agent to the next:

  Preference model -> Transport Agent -> Hotel Agent -> Budget Planner Agent
                   -> Attraction Agent -> Itinerary optimizer -> Budget check -> LLM summary
"""
import json
import math
from datetime import date

import numpy as np
import pandas as pd

from src import config, llm
from src.data_loader import city_match, load_attractions, load_flights, load_hotels
from src.optimizer import build_itinerary, itinerary_stats


# ===================================================================== Transport
class TransportAgent:
    """Finds outbound and return flights from the Indian flight-price dataset."""

    def __init__(self):
        self.flights = load_flights()

    def _options(self, src, dst, days_left, flight_class, travelers):
        df = self.flights[city_match(self.flights["source_city"], src)
                          & city_match(self.flights["destination_city"], dst)]
        if df.empty:
            return []
        by_class = df[df["class"].str.lower() == flight_class.lower()]
        df = by_class if not by_class.empty else df
        near = df[(df["days_left"] - days_left).abs() <= 3]      # prices depend on booking lead time
        df = near if not near.empty else df
        # One row per flight number: median price is a robust estimate
        g = (df.groupby(["airline", "flight", "stops", "departure_time", "arrival_time", "class"], as_index=False)
               .agg(price=("price", "median"), duration=("duration", "median")))
        p = (g["price"] - g["price"].min()) / (g["price"].max() - g["price"].min() + 1e-9)
        t = (g["duration"] - g["duration"].min()) / (g["duration"].max() - g["duration"].min() + 1e-9)
        g["value_score"] = 0.7 * p + 0.3 * t                      # lower is better
        picks = []
        for label, row in [("Cheapest", g.nsmallest(1, "price")), ("Fastest", g.nsmallest(1, "duration")),
                           ("Best value", g.nsmallest(1, "value_score"))]:
            r = row.iloc[0].to_dict()
            r.update(label=label, price=int(r["price"]), total=int(r["price"]) * travelers,
                     duration=round(float(r["duration"]), 2))
            picks.append(r)
        return picks

    def run(self, source, destination, start, end, travelers, flight_class="Economy"):
        if source.strip().lower() == destination.strip().lower():
            return {"mode": "Local", "outbound": [], "return": [], "total": 0,
                    "note": "Source and destination are the same city."}
        days_left = int(np.clip((start - date.today()).days, 1, 49))
        out = self._options(source, destination, days_left, flight_class, travelers)
        ret = self._options(destination, source, int(np.clip(days_left + (end - start).days, 1, 49)),
                            flight_class, travelers)
        if out and ret:
            chosen_out = next(o for o in out if o["label"] == "Best value")
            chosen_ret = next(o for o in ret if o["label"] == "Best value")
            return {"mode": "Flight", "outbound": out, "return": ret,
                    "chosen": {"outbound": chosen_out, "return": chosen_ret},
                    "total": chosen_out["total"] + chosen_ret["total"],
                    "cheapest_total": min(o["total"] for o in out) + min(o["total"] for o in ret),
                    "note": f"Prices from the Kaggle flight dataset for bookings ~{days_left} days ahead."}
        est = config.GROUND_TRANSPORT_EST_PER_PERSON_ONE_WAY * 2 * travelers
        return {"mode": "Road/Rail (estimate)", "outbound": [], "return": [], "total": est, "cheapest_total": est,
                "note": (f"No {source} → {destination} route in the flight dataset (it covers 6 metro cities). "
                         f"Using a planning estimate of ₹{config.GROUND_TRANSPORT_EST_PER_PERSON_ONE_WAY:,} "
                         "per person each way by road/rail.")}


# ========================================================================= Hotel
class HotelAgent:
    """Shortlists hotels in the destination city that match the predicted tier."""

    def __init__(self):
        self.hotels = load_hotels()

    def run(self, city, tier, nights, travelers):
        nights = max(nights, 1)
        rooms = math.ceil(travelers / 2)
        lo, hi = config.TIER_PROFILE[tier]["hotel_stars"]
        in_city = self.hotels[city_match(self.hotels["city"], city)]
        match = in_city[in_city["stars"].between(lo, hi)]
        note = f"{len(match)} hotels in {city} match {lo}–{hi}★ for the '{tier}' tier."
        if match.empty and not in_city.empty:
            match, note = in_city, f"No {lo}–{hi}★ hotels in {city}; showing all {len(in_city)} hotels there."
        if match.empty:
            star = hi
            price = config.EST_PRICE_BY_STAR[star]
            fake = {"name": f"{star}★ hotel (estimate)", "city": city, "stars": star, "rating": np.nan,
                    "price": price, "price_estimated": True, "locality": "", "facilities": "",
                    "cost": price * nights * rooms}
            return {"options": [fake], "chosen": fake, "rooms": rooms, "nights": nights,
                    "note": f"No hotels for {city} in the dataset; using a {star}★ price estimate."}
        df = match.copy()
        # value = good rating for the money
        df["value"] = df["rating"].fillna(3.5) / np.log1p(df["price"])
        df["cost"] = (df["price"] * nights * rooms).astype(int)
        options = df.sort_values(["value", "rating"], ascending=False).head(6)
        cheaper = in_city.assign(cost=(in_city["price"] * nights * rooms).astype(int)).nsmallest(3, "price")
        opts = options.to_dict("records")
        return {"options": opts, "chosen": opts[0], "cheaper": cheaper.to_dict("records"),
                "rooms": rooms, "nights": nights,
                "note": note + (" Prices estimated from star rating (dataset has no tariff column)."
                                if bool(df["price_estimated"].any()) else "")}


# ==================================================================== Attraction
class AttractionAgent:
    """Ranks the destination's attractions by rating, popularity and the user's interests."""

    def __init__(self):
        self.places = load_attractions()

    def run(self, city, interests):
        df = self.places[city_match(self.places["city"], city)].copy()
        if df.empty:
            return df
        wanted = [i.lower() for i in interests]
        text = (df["significance"] + " " + df["type"]).str.lower()
        df["interest_match"] = text.apply(lambda s: any(w in s for w in wanted)) if wanted else False
        df["score"] = (df["rating"] + 0.3 * np.log1p(df["reviews_lakhs"] * 10)
                       + 1.0 * df["interest_match"].astype(float))
        return df.sort_values("score", ascending=False).reset_index(drop=True)


# ================================================================ Budget Planner
class BudgetPlannerAgent:
    """Fits transport + hotel + daily costs into the budget and leaves an allowance for attractions."""

    def plan(self, budget, transport, hotel, tier, days, travelers):
        misc_rate = config.TIER_PROFILE[tier]["daily_misc"]
        steps = []
        t_cost = transport["total"]
        h_choice = hotel["chosen"]
        misc = misc_rate * days * travelers

        def fixed():
            return t_cost + h_choice["cost"] + misc

        if fixed() > budget and hotel.get("cheaper"):
            cheapest = min(hotel["cheaper"], key=lambda h: h["cost"])
            if cheapest["cost"] < h_choice["cost"]:
                steps.append(f"Hotel downgraded to {cheapest['name']} (saves ₹{h_choice['cost'] - cheapest['cost']:,}).")
                h_choice = cheapest
        if fixed() > budget and transport.get("cheapest_total", t_cost) < t_cost:
            steps.append(f"Switched to the cheapest flights (saves ₹{t_cost - transport['cheapest_total']:,}).")
            t_cost = transport["cheapest_total"]
        basic = config.TIER_PROFILE["Basic"]["daily_misc"]
        if fixed() > budget and misc_rate > basic:
            steps.append(f"Daily spend reduced to the Basic level ₹{basic}/person/day.")
            misc_rate, misc = basic, basic * days * travelers

        allowance = max(budget - fixed(), 0)
        return {"transport": int(t_cost), "hotel": int(h_choice["cost"]), "hotel_choice": h_choice,
                "daily_misc": int(misc), "daily_misc_rate": misc_rate,
                "activity_allowance_per_person": allowance / travelers, "adjustments": steps}

    def summary(self, budget, plan, fees_per_person, travelers):
        activities = int(fees_per_person * travelers)
        total = plan["transport"] + plan["hotel"] + plan["daily_misc"] + activities
        breakdown = {"Transport": plan["transport"], "Hotel": plan["hotel"],
                     "Food & local travel": plan["daily_misc"], "Attraction fees": activities}
        return {"breakdown": breakdown, "total": total, "budget": budget,
                "remaining": budget - total, "within_budget": total <= budget,
                "adjustments": plan["adjustments"]}


# ================================================================== Orchestrator
class TravelOrchestrator:
    def __init__(self, preference_model):
        self.model = preference_model
        self.transport = TransportAgent()
        self.hotel = HotelAgent()
        self.attraction = AttractionAgent()
        self.budget = BudgetPlannerAgent()

    def plan_trip(self, profile, source, destination, start, end, budget, interests, tier_override=None):
        days = (end - start).days + 1
        travelers = int(profile["NumberOfPersonVisiting"]) + int(profile.get("NumberOfChildrenVisiting", 0))
        tier, probs = self.model.predict(profile)
        tier = tier_override or tier
        tp = config.TIER_PROFILE[tier]

        transport = self.transport.run(source, destination, start, end, travelers, tp["flight_class"])
        hotel = self.hotel.run(destination, tier, nights=days - 1, travelers=travelers)
        bplan = self.budget.plan(budget, transport, hotel, tier, days, travelers)
        places = self.attraction.run(destination, interests)
        itinerary = build_itinerary(places, start, days, bplan["activity_allowance_per_person"],
                                    config.DAILY_HOURS) if not places.empty else []
        stats = itinerary_stats(itinerary)
        bsum = self.budget.summary(budget, bplan, stats["fees_per_person"], travelers)

        result = {"tier": tier, "probs": probs, "days": days, "travelers": travelers,
                  "source": source, "destination": destination, "start": start, "end": end,
                  "transport": transport, "hotel": hotel, "hotel_choice": bplan["hotel_choice"],
                  "attractions": places, "itinerary": itinerary, "stats": stats, "budget": bsum,
                  "interests": interests}
        result["narrative"] = self.narrate(result)
        return result

    @staticmethod
    def narrate(r):
        """LLM write-up of the plan (MAAS); template text if the LLM is unavailable."""
        brief = {
            "trip": f"{r['source']} to {r['destination']}, {r['days']} days, {r['travelers']} travelers",
            "preference_tier": r["tier"], "interests": r["interests"],
            "hotel": r["hotel_choice"]["name"], "transport": r["transport"]["mode"],
            "itinerary": [{"day": d["day"], "date": d["date"], "stops": [s["name"] for s in d["stops"]]}
                          for d in r["itinerary"]],
            "budget": r["budget"]["breakdown"], "total": r["budget"]["total"], "budget_limit": r["budget"]["budget"],
        }
        text = llm.chat(
            system=("You are a friendly travel planner. Write a short, warm trip summary (max 200 words) "
                    "from the JSON plan. Do not invent places, prices or facts not in the JSON."),
            user=json.dumps(brief, default=str))
        if text:
            return text
        lines = [f"**Your {r['days']}-day {r['tier']} trip to {r['destination']}** for {r['travelers']} "
                 f"traveller(s), staying at **{r['hotel_choice']['name']}**, travelling by {r['transport']['mode'].lower()}."]
        for d in r["itinerary"]:
            names = ", ".join(s["name"] for s in d["stops"]) or "Free time / rest"
            lines.append(f"- **Day {d['day']} ({d['date']})**: {names}")
        b = r["budget"]
        lines.append(f"\nEstimated total ₹{b['total']:,} of your ₹{b['budget']:,} budget "
                     f"({'within budget' if b['within_budget'] else 'over budget'}).")
        return "\n".join(lines)


def flights_to_df(options):
    if not options:
        return pd.DataFrame()
    cols = ["label", "airline", "flight", "stops", "departure_time", "arrival_time", "duration", "price", "total"]
    return pd.DataFrame(options)[cols].rename(columns={"duration": "hours", "price": "fare/person"})
