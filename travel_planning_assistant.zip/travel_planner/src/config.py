"""Central configuration: file paths, dataset file names and planning constants."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# DATA_DIR can be overridden (e.g. tests point it at tests/mock_data)
DATA_DIR = Path(os.getenv("DATA_DIR", ROOT / "data" / "raw"))
KB_DIR = ROOT / "data" / "knowledge_base"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"

# ---- Kaggle files (see docs/dataset_sources.md) -----------------------------
CUSTOMER_FILE = "Travel.csv"                       # Holiday Package Purchase Prediction
FLIGHT_FILE = "Clean_Dataset.csv"                  # Flight Price Prediction (India)
ATTRACTION_FILE = "Top Indian Places to Visit.csv" # Travel Dataset: Guide to India's Must-See Places
HOTEL_FILE = "goibibo_com-travel_sample.csv"       # Hotels on Goibibo (PromptCloud)

MODEL_PATH = MODEL_DIR / "preference_model.joblib"
MODEL_META_PATH = MODEL_DIR / "model_meta.json"

# ---- ML ----------------------------------------------------------------------
TARGET = "ProductPitched"   # Basic / Standard / Deluxe / Super Deluxe / King
NUMERIC_FEATURES = [
    "Age", "CityTier", "NumberOfPersonVisiting", "PreferredPropertyStar",
    "NumberOfTrips", "Passport", "OwnCar", "NumberOfChildrenVisiting", "MonthlyIncome",
]
CATEGORICAL_FEATURES = ["Occupation", "Gender", "MaritalStatus"]
# "Designation" is deliberately NOT used: in this dataset it maps almost 1-to-1
# to ProductPitched, so it would leak the answer.
RANDOM_STATE = 42

TIER_ORDER = ["Basic", "Standard", "Deluxe", "Super Deluxe", "King"]

# What each predicted tier means for the trip.
#   hotel_stars : acceptable hotel star range
#   flight_class: class searched first
#   daily_misc  : food + local transport per person per day (INR, planning estimate)
TIER_PROFILE = {
    "Basic":        {"hotel_stars": (1, 3), "flight_class": "Economy",  "daily_misc": 800},
    "Standard":     {"hotel_stars": (2, 3), "flight_class": "Economy",  "daily_misc": 1200},
    "Deluxe":       {"hotel_stars": (3, 4), "flight_class": "Economy",  "daily_misc": 1800},
    "Super Deluxe": {"hotel_stars": (4, 5), "flight_class": "Economy",  "daily_misc": 2500},
    "King":         {"hotel_stars": (5, 5), "flight_class": "Business", "daily_misc": 4000},
}

# Used only when the hotel dataset has no price column / no hotel for the city.
EST_PRICE_BY_STAR = {0: 1500, 1: 1200, 2: 1800, 3: 3000, 4: 5500, 5: 9500}
# Used only when the flight dataset has no route (destination is not a metro).
GROUND_TRANSPORT_EST_PER_PERSON_ONE_WAY = 2500

DAILY_HOURS = 8.0   # sightseeing hours per day for the optimizer

# ---- LLM via MAAS (OpenAI-compatible endpoint). Leave empty to run offline. ----
MAAS_BASE_URL = os.getenv("MAAS_BASE_URL", "")
MAAS_API_KEY = os.getenv("MAAS_API_KEY", "")
MAAS_MODEL = os.getenv("MAAS_MODEL", "")
