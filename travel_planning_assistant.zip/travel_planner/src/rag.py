"""Retrieval-Augmented Generation over tourism guides, hotel policies and travel advisories.

Documents come from three places:
  1. Tourism guides  – one document per attraction row (Kaggle attractions dataset)
  2. Hotel info      – one document per hotel row (Kaggle hotel dataset: facilities/description)
  3. Knowledge base  – markdown files in data/knowledge_base/ (hotel policies, travel advisories)

Retrieval uses TF-IDF + cosine similarity (scikit-learn), so it needs no model
download and runs inside the AI Lab VM. The retrieved chunks are passed to the
MAAS LLM to write the answer; without an LLM the top chunks are shown directly.
"""
import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from src import config, llm
from src.data_loader import load_attractions, load_hotels


def _chunk_markdown(text, source):
    """Split a markdown file on '## ' headings; each section is one chunk."""
    docs = []
    for part in re.split(r"\n(?=## )", text):
        part = part.strip()
        if len(part) > 40:
            title = part.splitlines()[0].lstrip("# ").strip()
            docs.append({"text": part, "source": source, "title": title})
    return docs


def build_documents():
    docs = []
    try:
        for r in load_attractions().itertuples():
            docs.append({
                "source": "Tourism guide (Kaggle attractions)", "title": f"{r.name}, {r.city}",
                "text": (f"{r.name} is a {r.type} in {r.city}, {r.state} ({r.zone} zone). "
                         f"Significance: {r.significance}. Google rating {r.rating}/5. "
                         f"Entrance fee: INR {int(r.fee)}. Time needed: about {r.hours} hours. "
                         f"Best time to visit: {r.best_time}. Weekly off: {r.weekly_off}."),
            })
    except FileNotFoundError:
        pass
    try:
        for r in load_hotels().itertuples():
            price = f"approx. INR {int(r.price)}/night" + (" (estimated from star rating)" if r.price_estimated else "")
            docs.append({
                "source": "Hotel info (Kaggle hotels)", "title": f"{r.name}, {r.city}",
                "text": (f"{r.name} in {r.city} {('- ' + r.locality) if r.locality else ''}. "
                         f"{r.stars}-star, guest rating {r.rating}. {price}. "
                         f"Facilities: {r.facilities[:300]}. {r.description[:400]}"),
            })
    except FileNotFoundError:
        pass
    for f in sorted(config.KB_DIR.glob("*.md")):
        docs.extend(_chunk_markdown(f.read_text(encoding="utf-8"), f.stem.replace("_", " ").title()))
    return docs


class RAG:
    def __init__(self, docs=None):
        self.docs = docs if docs is not None else build_documents()
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
        self.matrix = self.vectorizer.fit_transform([d["title"] + ". " + d["text"] for d in self.docs])

    def retrieve(self, query, k=4, min_score=0.03):
        sims = cosine_similarity(self.vectorizer.transform([query]), self.matrix)[0]
        top = sims.argsort()[::-1][:k]
        return [dict(self.docs[i], score=round(float(sims[i]), 3)) for i in top if sims[i] >= min_score]

    def answer(self, question, k=4):
        hits = self.retrieve(question, k)
        if not hits:
            return "I couldn't find anything about that in the travel knowledge base.", []
        context = "\n\n".join(f"[{i+1}] ({h['source']} – {h['title']})\n{h['text']}" for i, h in enumerate(hits))
        reply = llm.chat(
            system=("You are a travel assistant. Answer ONLY from the numbered context. "
                    "Cite sources like [1]. If the context does not contain the answer, say so."),
            user=f"Context:\n{context}\n\nQuestion: {question}",
        )
        if reply is None:  # offline fallback: show the best passages
            reply = "Here is what the knowledge base says:\n\n" + "\n\n".join(
                f"**[{i+1}] {h['title']}** — {h['text'][:500]}" for i, h in enumerate(hits))
        return reply, hits
